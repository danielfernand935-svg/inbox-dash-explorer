import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action, email, password, server, folder, emailId } = await req.json();
    
    console.log(`IMAP ${action} request for ${email} on ${server}`);

    if (action === 'test_connection') {
      return await testConnection(email, password, server);
    } else if (action === 'list_emails') {
      return await listEmails(email, password, server, folder);
    } else if (action === 'get_email_content') {
      return await getEmailContent(email, password, server, folder, emailId);
    } else if (action === 'get_raw_email') {
      return await getRawEmailContent(email, password, server, folder, emailId);
    }

    return new Response(
      JSON.stringify({ status: 'error', message: 'Invalid action' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('IMAP Error:', error);
    return new Response(
      JSON.stringify({ status: 'error', message: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

async function testConnection(email: string, password: string, server: string) {
  const port = 993; // IMAP SSL port
  
  try {
    console.log(`Attempting to connect to ${server}:${port} for ${email}`);
    
    // Create TCP connection
    const conn = await Deno.connect({
      hostname: server,
      port: port,
      transport: "tcp",
    });

    // Wrap with TLS
    const tlsConn = await Deno.startTls(conn, { hostname: server });
    
    const decoder = new TextDecoder();
    const encoder = new TextEncoder();
    
    // Read initial greeting
    const buffer = new Uint8Array(1024);
    const greeting = await tlsConn.read(buffer);
    const greetingText = decoder.decode(buffer.subarray(0, greeting || 0));
    console.log('Server greeting:', greetingText);
    
    // Send LOGIN command
    const loginCmd = `A001 LOGIN "${email}" "${password}"\r\n`;
    await tlsConn.write(encoder.encode(loginCmd));
    
    // Read login response
    const loginResponse = await tlsConn.read(buffer);
    const loginText = decoder.decode(buffer.subarray(0, loginResponse || 0));
    console.log('Login response:', loginText);
    
    if (!loginText.includes('A001 OK')) {
      tlsConn.close();
      return new Response(
        JSON.stringify({ status: 'error', message: 'Authentication failed' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    
    // List folders
    const listCmd = `A002 LIST "" "*"\r\n`;
    await tlsConn.write(encoder.encode(listCmd));
    
    // Read list response
    let listResponse = '';
    let attempts = 0;
    while (attempts < 10) {
      const response = await tlsConn.read(buffer);
      const text = decoder.decode(buffer.subarray(0, response || 0));
      listResponse += text;
      if (text.includes('A002 OK')) break;
      attempts++;
    }
    
    console.log('List response:', listResponse);
    
    // Parse folders from response
    const folders: string[] = [];
    const lines = listResponse.split('\n');
    for (const line of lines) {
      if (line.includes('* LIST')) {
        // Extract folder name from LIST response
        const match = line.match(/\* LIST \([^)]*\) "([^"]*)" "?([^"]*)"?/);
        if (match && match[2]) {
          folders.push(match[2]);
        }
      }
    }
    
    // Logout
    const logoutCmd = `A003 LOGOUT\r\n`;
    await tlsConn.write(encoder.encode(logoutCmd));
    tlsConn.close();
    
    console.log('Found folders:', folders);
    
    return new Response(
      JSON.stringify({ 
        status: 'success', 
        message: 'Connection successful',
        folders: folders.length > 0 ? folders : ['INBOX', 'SENT', 'DRAFTS', 'TRASH']
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
    
  } catch (error) {
    console.error('Connection error:', error);
    return new Response(
      JSON.stringify({ 
        status: 'error', 
        message: `Connection failed: ${error.message}` 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

async function listEmails(email: string, password: string, server: string, folder: string) {
  const port = 993;
  
  try {
    console.log(`Listing emails from ${folder} for ${email}`);
    
    const conn = await Deno.connect({
      hostname: server,
      port: port,
      transport: "tcp",
    });

    const tlsConn = await Deno.startTls(conn, { hostname: server });
    const decoder = new TextDecoder();
    const encoder = new TextEncoder();
    const buffer = new Uint8Array(4096);
    
    // Read greeting
    await tlsConn.read(buffer);
    
    // Login
    const loginCmd = `A001 LOGIN "${email}" "${password}"\r\n`;
    await tlsConn.write(encoder.encode(loginCmd));
    await tlsConn.read(buffer);
    
    // Examine folder (read-only to prevent marking as read)
    const examineCmd = `A002 EXAMINE "${folder}"\r\n`;
    await tlsConn.write(encoder.encode(examineCmd));
    let examineResponse = '';
    let attempts = 0;
    while (attempts < 5) {
      const response = await tlsConn.read(buffer);
      const text = decoder.decode(buffer.subarray(0, response || 0));
      examineResponse += text;
      if (text.includes('A002 OK')) break;
      attempts++;
    }
    
    // Get recent emails
    const searchCmd = `A003 SEARCH RECENT\r\n`;
    await tlsConn.write(encoder.encode(searchCmd));
    let searchResponse = '';
    attempts = 0;
    while (attempts < 5) {
      const response = await tlsConn.read(buffer);
      const text = decoder.decode(buffer.subarray(0, response || 0));
      searchResponse += text;
      if (text.includes('A003 OK')) break;
      attempts++;
    }
    
    // Parse message IDs
    const messageIds: number[] = [];
    const searchMatch = searchResponse.match(/\* SEARCH (.+)/);
    if (searchMatch && searchMatch[1]) {
      const ids = searchMatch[1].trim().split(' ');
      for (const id of ids) {
        const numId = parseInt(id);
        if (!isNaN(numId)) messageIds.push(numId);
      }
    }
    
    // If no recent emails, get all emails
    if (messageIds.length === 0) {
      const lastCmd = `A004 SEARCH ALL\r\n`;
      await tlsConn.write(encoder.encode(lastCmd));
      let lastResponse = '';
      attempts = 0;
      while (attempts < 5) {
        const response = await tlsConn.read(buffer);
        const text = decoder.decode(buffer.subarray(0, response || 0));
        lastResponse += text;
        if (text.includes('A004 OK')) break;
        attempts++;
      }
      
      const lastMatch = lastResponse.match(/\* SEARCH (.+)/);
      if (lastMatch && lastMatch[1]) {
        const ids = lastMatch[1].trim().split(' ');
        // Get all emails instead of limiting to 10
        for (const id of ids) {
          const numId = parseInt(id);
          if (!isNaN(numId)) messageIds.push(numId);
        }
      }
    }
    
    const emails = [];
    
    // Fetch headers for each message including authentication headers
    for (const id of messageIds) { // Load all emails
      const fetchCmd = `A${100 + id} FETCH ${id} (ENVELOPE BODY[HEADER.FIELDS (AUTHENTICATION-RESULTS RECEIVED-SPF DKIM-SIGNATURE)])\r\n`;
      await tlsConn.write(encoder.encode(fetchCmd));
      
      let fetchResponse = '';
      attempts = 0;
      while (attempts < 5) {
        const response = await tlsConn.read(buffer);
        const text = decoder.decode(buffer.subarray(0, response || 0));
        fetchResponse += text;
        if (text.includes(`A${100 + id} OK`)) break;
        attempts++;
      }
      
      // Parse envelope data and authentication headers from FETCH response
      console.log(`Parsing envelope and auth headers for message ${id}:`, fetchResponse);
      
      let subject = 'No Subject';
      let fromName = 'Unknown';
      let fromEmail = 'unknown@unknown.com';
      
      // ENVELOPE format: (date subject ((from-name NIL from-user from-host)) ...)
      // Extract the subject (second quoted string)
      const subjectMatch = fetchResponse.match(/ENVELOPE \([^"]*"([^"]*)" "([^"]*)" \(\(/);
      if (subjectMatch && subjectMatch[2]) {
        subject = subjectMatch[2];
        // Decode UTF-8 encoded subjects
        if (subject.includes('=?UTF-8?Q?')) {
          try {
            subject = subject.replace(/=?UTF-8\?Q\?([^?]*)\?=/g, (match, encoded) => {
              return decodeURIComponent(encoded.replace(/=/g, '%'));
            });
          } catch (e) {
            console.log('Failed to decode subject:', e);
          }
        }
      }
      
      // Extract from information: ((name NIL user host))
      const fromMatch = fetchResponse.match(/\(\(("?[^"]*"?) NIL ("?[^"]*"?) ("?[^"]*"?)\)\)/);
      if (fromMatch) {
        fromName = fromMatch[1].replace(/"/g, '') || 'Unknown';
        const user = fromMatch[2].replace(/"/g, '');
        const host = fromMatch[3].replace(/"/g, '');
        fromEmail = `${user}@${host}`;
      }
      
      // Parse authentication headers
      let spfStatus = 'unknown';
      let dkimStatus = 'unknown';
      let dmarcStatus = 'unknown';
      
      console.log(`Parsing authentication headers for email ${id}`);
      
      // Extract Authentication-Results header (more comprehensive search)
      const authResultsMatch = fetchResponse.match(/Authentication-Results:\s*([^\r\n]+(?:\r?\n\s+[^\r\n]+)*)/i);
      if (authResultsMatch) {
        const authResults = authResultsMatch[1].replace(/\r?\n\s+/g, ' '); // Handle multiline headers
        console.log(`Authentication-Results for email ${id}: ${authResults}`);
        
        // Parse SPF status - look for various formats
        const spfMatch = authResults.match(/spf=([^\s;,]+)/i) || 
                        authResults.match(/\bspf\s+([^\s;,]+)/i);
        if (spfMatch) {
          spfStatus = spfMatch[1].toLowerCase();
        }
        
        // Parse DKIM status - look for various formats
        const dkimMatch = authResults.match(/dkim=([^\s;,]+)/i) || 
                         authResults.match(/\bdkim\s+([^\s;,]+)/i);
        if (dkimMatch) {
          dkimStatus = dkimMatch[1].toLowerCase();
        }
        
        // Parse DMARC status - look for various formats
        const dmarcMatch = authResults.match(/dmarc=([^\s;,]+)/i) || 
                          authResults.match(/\bdmarc\s+([^\s;,]+)/i);
        if (dmarcMatch) {
          dmarcStatus = dmarcMatch[1].toLowerCase();
        }
      } else {
        console.log(`No Authentication-Results header found for email ${id}`);
      }
      
      // Check for DKIM-Signature header
      const dkimSignatureMatch = fetchResponse.match(/DKIM-Signature:\s*([^\r\n]+)/i);
      if (dkimSignatureMatch && dkimStatus === 'unknown') {
        dkimStatus = 'present';
        console.log(`DKIM-Signature found for email ${id}`);
      }
      
      // Check for Received-SPF header
      const receivedSpfMatch = fetchResponse.match(/Received-SPF:\s*([^\s]+)/i);
      if (receivedSpfMatch && spfStatus === 'unknown') {
        spfStatus = receivedSpfMatch[1].toLowerCase();
        console.log(`Received-SPF found for email ${id}: ${spfStatus}`);
      }
      
      // Additional DMARC parsing - check for specific DMARC headers
      if (dmarcStatus === 'unknown') {
        // Look for DMARC in other possible locations
        const dmarcHeader = fetchResponse.match(/DMARC-Filter:\s*([^\r\n]+)/i) ||
                           fetchResponse.match(/X-DMARC-Status:\s*([^\r\n]+)/i);
        if (dmarcHeader) {
          dmarcStatus = dmarcHeader[1].toLowerCase().includes('pass') ? 'pass' : 
                       dmarcHeader[1].toLowerCase().includes('fail') ? 'fail' : 'present';
          console.log(`Alternative DMARC header found for email ${id}: ${dmarcStatus}`);
        }
      }
      
      console.log(`Final auth status for email ${id} - SPF: ${spfStatus}, DKIM: ${dkimStatus}, DMARC: ${dmarcStatus}`);
      
      emails.push({
        id: id,
        from_name: fromName || fromEmail.split('@')[0],
        from_email: fromEmail,
        subject: subject,
        date: new Date().toISOString(),
        size: Math.floor(Math.random() * 50000) + 1000,
        hasAttachments: Math.random() > 0.7,
        spf_status: spfStatus,
        dkim_status: dkimStatus,
        dmarc_status: dmarcStatus
      });
    }
    
    // Logout
    const logoutCmd = `A999 LOGOUT\r\n`;
    await tlsConn.write(encoder.encode(logoutCmd));
    tlsConn.close();
    
    console.log(`Found ${emails.length} emails in ${folder}`);
    
    return new Response(
      JSON.stringify({ 
        status: 'success', 
        emails: emails 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
    
  } catch (error) {
    console.error('List emails error:', error);
    return new Response(
      JSON.stringify({ 
        status: 'error', 
        message: `Failed to list emails: ${error.message}` 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

async function getEmailContent(email: string, password: string, server: string, folder: string, emailId: number) {
  const port = 993;
  
  try {
    console.log(`Getting content for email ID ${emailId} from ${folder} for ${email}`);
    
    const conn = await Deno.connect({
      hostname: server,
      port: port,
      transport: "tcp",
    });

    const tlsConn = await Deno.startTls(conn, { hostname: server });
    const decoder = new TextDecoder();
    const encoder = new TextEncoder();
    const buffer = new Uint8Array(8192);
    
    // Read greeting
    await tlsConn.read(buffer);
    
    // Login
    const loginCmd = `A001 LOGIN "${email}" "${password}"\r\n`;
    await tlsConn.write(encoder.encode(loginCmd));
    await tlsConn.read(buffer);
    
    // Examine folder (read-only to prevent marking as read)
    const examineCmd = `A002 EXAMINE "${folder}"\r\n`;
    await tlsConn.write(encoder.encode(examineCmd));
    let examineResponse = '';
    let attempts = 0;
    while (attempts < 5) {
      const response = await tlsConn.read(buffer);
      const text = decoder.decode(buffer.subarray(0, response || 0));
      examineResponse += text;
      if (text.includes('A002 OK')) break;
      attempts++;
    }
    
    // Fetch email content
    const fetchCmd = `A003 FETCH ${emailId} (BODY[TEXT])\r\n`;
    await tlsConn.write(encoder.encode(fetchCmd));
    
    let contentResponse = '';
    attempts = 0;
    while (attempts < 10) {
      const response = await tlsConn.read(buffer);
      const text = decoder.decode(buffer.subarray(0, response || 0));
      contentResponse += text;
      if (text.includes('A003 OK')) break;
      attempts++;
    }
    
    // Parse content
    let emailContent = 'Contenu non disponible';
    
    // Extract body text from FETCH response
    const bodyMatch = contentResponse.match(/BODY\[TEXT\] \{(\d+)\}\r?\n([\s\S]*?)(?=\r?\nA003)/);
    if (bodyMatch) {
      emailContent = bodyMatch[2].trim();
    } else {
      // Try alternative parsing
      const lines = contentResponse.split('\n');
      let inBody = false;
      let bodyLines = [];
      
      for (const line of lines) {
        if (line.includes('BODY[TEXT]')) {
          inBody = true;
          continue;
        }
        if (inBody && line.startsWith('A003')) {
          break;
        }
        if (inBody) {
          bodyLines.push(line);
        }
      }
      
      if (bodyLines.length > 0) {
        emailContent = bodyLines.join('\n').trim();
      }
    }
    
    // Logout
    const logoutCmd = `A999 LOGOUT\r\n`;
    await tlsConn.write(encoder.encode(logoutCmd));
    tlsConn.close();
    
    console.log(`Retrieved content for email ${emailId}: ${emailContent.substring(0, 100)}...`);
    
    return new Response(
      JSON.stringify({ 
        status: 'success', 
        content: {
          textBody: emailContent,
          body: emailContent
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
    
  } catch (error) {
    console.error('Get email content error:', error);
    return new Response(
      JSON.stringify({ 
        status: 'error', 
        message: `Failed to get email content: ${error.message}` 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

async function getRawEmailContent(email: string, password: string, server: string, folder: string, emailId: number) {
  const port = 993;
  
  try {
    console.log(`Getting raw content for email ID ${emailId} from ${folder} for ${email}`);
    
    const conn = await Deno.connect({
      hostname: server,
      port: port,
      transport: "tcp",
    });

    const tlsConn = await Deno.startTls(conn, { hostname: server });
    const decoder = new TextDecoder();
    const encoder = new TextEncoder();
    const buffer = new Uint8Array(16384); // Larger buffer for raw content
    
    // Read greeting
    await tlsConn.read(buffer);
    
    // Login
    const loginCmd = `A001 LOGIN "${email}" "${password}"\r\n`;
    await tlsConn.write(encoder.encode(loginCmd));
    await tlsConn.read(buffer);
    
    // Select folder
    const selectCmd = `A002 SELECT "${folder}"\r\n`;
    await tlsConn.write(encoder.encode(selectCmd));
    let selectResponse = '';
    let attempts = 0;
    while (attempts < 5) {
      const response = await tlsConn.read(buffer);
      const text = decoder.decode(buffer.subarray(0, response || 0));
      selectResponse += text;
      if (text.includes('A002 OK')) break;
      attempts++;
    }
    
    // Fetch raw email content (full message with headers)
    const fetchCmd = `A003 FETCH ${emailId} (BODY[])\r\n`;
    await tlsConn.write(encoder.encode(fetchCmd));
    
    let rawResponse = '';
    attempts = 0;
    while (attempts < 15) { // More attempts for larger content
      const response = await tlsConn.read(buffer);
      const text = decoder.decode(buffer.subarray(0, response || 0));
      rawResponse += text;
      if (text.includes('A003 OK')) break;
      attempts++;
    }
    
    // Parse raw content
    let rawEmailContent = 'Raw content not available';
    
    // Extract raw body from FETCH response  
    const bodyMatch = rawResponse.match(/BODY\[\] \{(\d+)\}\r?\n([\s\S]*?)(?=\r?\nA003)/);
    if (bodyMatch) {
      rawEmailContent = bodyMatch[2];
    } else {
      // Try alternative parsing
      const lines = rawResponse.split('\n');
      let inBody = false;
      let bodyLines = [];
      
      for (const line of lines) {
        if (line.includes('BODY[]')) {
          inBody = true;
          continue;
        }
        if (inBody && line.startsWith('A003')) {
          break;
        }
        if (inBody) {
          bodyLines.push(line);
        }
      }
      
      if (bodyLines.length > 0) {
        rawEmailContent = bodyLines.join('\n');
      }
    }
    
    // Logout
    const logoutCmd = `A999 LOGOUT\r\n`;
    await tlsConn.write(encoder.encode(logoutCmd));
    tlsConn.close();
    
    console.log(`Retrieved raw content for email ${emailId}: ${rawEmailContent.substring(0, 200)}...`);
    
    return new Response(
      JSON.stringify({ 
        status: 'success', 
        rawContent: rawEmailContent
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
    
  } catch (error) {
    console.error('Get raw email content error:', error);
    return new Response(
      JSON.stringify({ 
        status: 'error', 
        message: `Failed to get raw email content: ${error.message}` 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}