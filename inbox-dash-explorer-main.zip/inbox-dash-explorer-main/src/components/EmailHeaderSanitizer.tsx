import React, { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Copy, Download, Upload, Trash2, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// --- Helper utils ---
function unfoldHeaders(raw: string) {
  // Split headers and body by first blank line (\r\n\r\n or \n\n)
  let headerEndIdx = raw.indexOf("\r\n\r\n");
  let sep = "\r\n\r\n";
  if (headerEndIdx === -1) {
    headerEndIdx = raw.indexOf("\n\n");
    sep = "\n\n";
  }
  const headerBlock = headerEndIdx === -1 ? raw : raw.slice(0, headerEndIdx);
  const body = headerEndIdx === -1 ? "" : raw.slice(headerEndIdx + sep.length);

  // Preserve original folding: build pairs {name, valueRaw}
  const lines = headerBlock.replace(/\r\n/g, "\n").split("\n");
  const headers: Array<{name: string, valueRaw: string}> = [];
  let current: {name: string, valueRaw: string} | null = null;
  
  for (const line of lines) {
    if (/^[\t ]/.test(line)) {
      // continuation
      if (current) current.valueRaw += "\n" + line;
    } else if (line.trim() !== "") {
      const idx = line.indexOf(":");
      if (idx !== -1) {
        if (current) headers.push(current);
        current = {
          name: line.slice(0, idx).trim(),
          valueRaw: line.slice(idx + 1).trimStart(),
        };
      } else {
        // malformed, treat as continuation
        if (current) current.valueRaw += "\n" + line;
      }
    }
  }
  if (current) headers.push(current);
  return { headers, body, sep };
}

function formatDateToCustom(dateStr: string) {
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return `Date: [D=>%A %d %B %y, %I:%M:%S %p (day %j)]`;
    
    const weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    
    const weekday = weekdays[d.getDay()];
    const day = String(d.getDate()).padStart(2, "0");
    const month = months[d.getMonth()];
    const year = String(d.getFullYear()).slice(-2);
    const dayOfYear = Math.floor((d.getTime() - new Date(d.getFullYear(), 0, 0).getTime()) / 86400000);
    
    let hours = d.getHours();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    const hoursStr = String(hours).padStart(2, "0");
    const minutes = String(d.getMinutes()).padStart(2, "0");
    const seconds = String(d.getSeconds()).padStart(2, "0");
    
    return `[D=>${weekday} ${day} ${month} ${year}, ${hoursStr}:${minutes}:${seconds} ${ampm} (day ${dayOfYear})]`;
  } catch {
    return `[D=>%A %d %B %y, %I:%M:%S %p (day %j)]`;
  }
}

function sanitizeAddresses(value: string) {
  if (!value) return value;
  // Replace any <local@domain> with placeholder, preserving display text
  let out = value.replace(/<[^>\s]+@[^>\s]+>/g, "<[USER]@[P_RPATH]>");
  // Replace bare emails not inside <>
  out = out.replace(/(?<![<\w])([A-Z0-9._%+-]+)@([A-Z0-9.-]+\.[A-Z]{2,})(?![>\w])/gi, "[USER]@[P_RPATH]");
  return out;
}

function sanitizeMessageId(value: string) {
  if (!value) return value;
  // Add [EID] between "<" and "@"
  return value.replace(/<([^@]+)@/g, "<[EID]$1@");
}

function sanitizeListUnsub(value: string) {
  if (!value) return value;
  let v = value.replace(/mailto:[^>,\s]+/gi, "mailto:unsubscribe@[P_RPATH]");
  v = v.replace(/https?:\/\/[^>,\s]+/gi, "http://[P_RPATH]/[OPTDOWN]");
  return v;
}

function rebuild(headers: Array<{name: string, valueRaw: string}>, body: string, sep: string) {
  // Build new header block: only Received headers + specific fields
  const received = headers.filter(h => h.name.toLowerCase() === "received");
  const map = new Map(headers.map(h => [h.name.toLowerCase(), h]));

  const out = [];
  
  // Keep all Received headers in original order
  for (const h of received) {
    out.push(`Received: ${h.valueRaw}`);
  }

  // Date - new format
  if (map.has("date")) {
    out.push(`Date: ${formatDateToCustom(map.get("date")!.valueRaw)}`);
  }

  // From - keep display name, replace email with noreply[4N]@[P_RPATH]
  if (map.has("from")) {
    const fromValue = map.get("from")!.valueRaw;
    // Check if there's a display name pattern: "Display Name" <email@domain>
    const displayNameMatch = fromValue.match(/^(.+?)\s*<[^>]+>$/);
    if (displayNameMatch) {
      // Preserve display name, replace email
      const displayName = displayNameMatch[1].trim();
      out.push(`From: ${displayName} <noreply[4N]@[P_RPATH]>`);
    } else {
      // No display name, just replace with email
      out.push(`From: <noreply[4N]@[P_RPATH]>`);
    }
  }

  // To - replace or add
  out.push(`To: t.s.s.i.0.8.b.s.l@gmail.com`);

  // Cc - replace or add
  out.push(`Cc: t.s.s.i.0.8.b.s.l@[geopodismtpd39]`);

  // Message-ID - add [EID] between < and @
  if (map.has("message-id")) {
    const originalId = map.get("message-id")!.valueRaw;
    out.push(`Message-ID: ${sanitizeMessageId(originalId)}`);
  }

  // Subject (as-is)
  if (map.has("subject")) {
    out.push(`Subject: ${map.get("subject")!.valueRaw}`);
  }

  // MIME-Version
  if (map.has("mime-version")) {
    out.push(`MIME-Version: ${map.get("mime-version")!.valueRaw}`);
  }

  // Content-Type
  if (map.has("content-type")) {
    out.push(`Content-Type: ${map.get("content-type")!.valueRaw}`);
  }

  // Sender - replace or add
  out.push(`Sender: [USER]@[P_FROM]`);

  // List-Unsubscribe - replace
  out.push(`List-Unsubscribe: <https://[P_RPATH]/unsubscribe?email=abuse@[P_RPATH]>`);

  // List-Unsubscribe-Post - replace
  out.push(`List-Unsubscribe-Post: List-Unsubscribe=One-Click`);

  // Preserve body exactly, join with CRLF CRLF
  const headerText = out.join("\r\n");
  return headerText + "\r\n\r\n" + body;
}

export default function EmailHeaderSanitizer() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [error, setError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleProcess = () => {
    try {
      setError("");
      const { headers, body, sep } = unfoldHeaders(input);
      const sanitized = rebuild(headers, body, sep);
      setOutput(sanitized);
      toast({
        title: "En-têtes sanitisés",
        description: "Le traitement des en-têtes email a été effectué avec succès",
      });
    } catch (e) {
      setError("Erreur lors du parsing. Vérifiez le contenu .eml brut.");
      console.error(e);
      toast({
        title: "Erreur",
        description: "Erreur lors du traitement des en-têtes",
        variant: "destructive",
      });
    }
  };

  const handleFile = async (file: File) => {
    if (!file) return;
    try {
      const text = await file.text();
      setInput(text);
      toast({
        title: "Fichier chargé",
        description: `Fichier ${file.name} chargé avec succès`,
      });
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible de lire le fichier",
        variant: "destructive",
      });
    }
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  };

  const copy = async (what: string) => {
    try {
      await navigator.clipboard.writeText(what);
      toast({
        title: "Copié",
        description: "Contenu copié dans le presse-papiers",
      });
    } catch {
      toast({
        title: "Erreur",
        description: "Impossible de copier dans le presse-papiers",
        variant: "destructive",
      });
    }
  };

  const downloadOut = () => {
    if (!output) return;
    const blob = new Blob([output], { type: "message/rfc822" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "sanitized.eml";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    toast({
      title: "Fichier téléchargé",
      description: "Le fichier .eml sanitisé a été téléchargé",
    });
  };

  const clearAll = () => {
    setInput("");
    setOutput("");
    setError("");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Sanitiseur d'En-têtes EML</h2>
          <p className="text-muted-foreground">
            Traitez et sanitisez les en-têtes d'emails tout en préservant le corps du message
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => fileRef.current?.click()}
            className="gap-2"
            variant="outline"
          >
            <Upload className="h-4 w-4" />
            Charger .eml
          </Button>
          <input
            ref={fileRef}
            type="file"
            accept=".eml,message/rfc822"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
          />
          <Button
            onClick={handleProcess}
            disabled={!input}
            className="gap-2"
          >
            <FileText className="h-4 w-4" />
            Sanitiser
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Input Section */}
        <Card
          onDrop={onDrop}
          onDragOver={(e) => e.preventDefault()}
          className="border-dashed border-2 hover:border-primary/50 transition-colors"
        >
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Contenu .eml brut</span>
              <Badge variant="outline">Glissez et déposez ou collez</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Collez votre contenu source .eml ici..."
              className="min-h-[400px] font-mono text-sm"
            />
            {error && (
              <div className="text-sm text-destructive bg-destructive/10 p-3 rounded-md">
                {error}
              </div>
            )}
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => copy(input)}
                disabled={!input}
                className="gap-2"
              >
                <Copy className="h-4 w-4" />
                Copier
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={clearAll}
                className="gap-2"
              >
                <Trash2 className="h-4 w-4" />
                Effacer
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Output Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Résultat (en-têtes sanitisés)</span>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copy(output)}
                  disabled={!output}
                  className="gap-2"
                >
                  <Copy className="h-4 w-4" />
                  Copier
                </Button>
                <Button
                  size="sm"
                  onClick={downloadOut}
                  disabled={!output}
                  className="gap-2"
                >
                  <Download className="h-4 w-4" />
                  Télécharger .eml
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              value={output}
              onChange={(e) => setOutput(e.target.value)}
              placeholder="Le résultat sanitisé apparaîtra ici après avoir cliqué sur Sanitiser"
              className="min-h-[400px] font-mono text-sm"
              readOnly
            />
            {output && (
              <div className="mt-4 text-xs text-muted-foreground leading-relaxed bg-muted/50 p-3 rounded-md">
                <strong>Règles appliquées :</strong>{" "}
                <code className="bg-background px-1 rounded">Received</code> → conservés,{" "}
                <code className="bg-background px-1 rounded">Date</code> → format personnalisé{" "}
                <code className="bg-background px-1 rounded">[D=&gt;...]</code>,{" "}
                <code className="bg-background px-1 rounded">From</code> → <code className="bg-background px-1 rounded">&lt;noreply[4N]@[P_RPATH]&gt;</code>,{" "}
                <code className="bg-background px-1 rounded">To/Cc</code> → valeurs spécifiques,{" "}
                <code className="bg-background px-1 rounded">Message-ID</code> → préfixé avec <code className="bg-background px-1 rounded">[EID]</code>,{" "}
                <code className="bg-background px-1 rounded">Sender</code> → <code className="bg-background px-1 rounded">[USER]@[P_FROM]</code>,{" "}
                <code className="bg-background px-1 rounded">List-Unsubscribe</code> → valeurs standardisées.
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="text-xs text-muted-foreground text-center">
        <strong>Astuce :</strong> Le corps du contenu reste exactement tel quel ; seuls les en-têtes au-dessus de la première ligne vide sont réécrits.
      </div>
    </div>
  );
}