import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Progress } from "@/components/ui/progress";
import { Mail, Server, Shield, Search, Download, Calendar, User, ArrowRight, CheckCircle2, AlertCircle, FileText } from "lucide-react";
import EmailHeaderSanitizer from "./EmailHeaderSanitizer";


interface Email {
  id: number;
  from_name: string;
  from_email: string;
  subject: string;
  date: string;
  size: string;
  hasAttachments: boolean;
  spf_status?: string;
  dkim_status?: string;
  dmarc_status?: string;
}

interface ConnectionStatus {
  connected: boolean;
  message: string;
  folders: string[];
}

export default function EmailClient() {
  const [credentials, setCredentials] = useState({
    email: "",
    password: "",
    server: "imap.gmail.com"
  });
  
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>({
    connected: false,
    message: "",
    folders: []
  });
  
  const [selectedFolder, setSelectedFolder] = useState("");
  const [emails, setEmails] = useState<Email[]>([]);
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
  const [emailContent, setEmailContent] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [loadingContent, setLoadingContent] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const [authFilter, setAuthFilter] = useState<string>("all");
  const [activeTab, setActiveTab] = useState<"client" | "sanitizer">("client");
  
  const { toast } = useToast();

  const testConnection = async () => {
    if (!credentials.email || !credentials.password || !credentials.server) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs de connexion",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('imap-connection', {
        body: { 
          action: 'test_connection',
          email: credentials.email,
          password: credentials.password,
          server: credentials.server
        }
      });

      if (error) throw error;

      if (data.status === 'success') {
        setConnectionStatus({
          connected: true,
          message: data.message,
          folders: data.folders,
        });

        toast({
          title: "Connexion réussie",
          description: "Connecté au serveur IMAP",
        });
      } else {
        throw new Error(data.message);
      }
    } catch (error) {
      console.error('Connection error:', error);
      setConnectionStatus({
        connected: false,
        message: "Erreur de connexion: " + (error.message || "Erreur inconnue"),
        folders: [],
      });

      toast({
        title: "Erreur de connexion",
        description: error.message || "Impossible de se connecter au serveur",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const loadEmails = async () => {
    if (!selectedFolder) return;

    setLoading(true);
    setLoadingProgress(0);
    
    // Simulate progress during loading
    const progressInterval = setInterval(() => {
      setLoadingProgress(prev => {
        if (prev >= 90) return prev;
        return prev + Math.random() * 15;
      });
    }, 200);

    try {
      const { data, error } = await supabase.functions.invoke('imap-connection', {
        body: { 
          action: 'list_emails',
          email: credentials.email,
          password: credentials.password,
          server: credentials.server,
          folder: selectedFolder
        }
      });

      if (error) throw error;

      if (data.status === 'success') {
        // Transform the data to match our Email interface
        const transformedEmails: Email[] = data.emails.map((email: any) => ({
          id: email.id,
          from_name: email.from_name,
          from_email: email.from_email,
          subject: email.subject,
          date: email.date,
          size: `${Math.round(email.size / 1024)} KB`,
          hasAttachments: email.hasAttachments,
          spf_status: email.spf_status || 'unknown',
          dkim_status: email.dkim_status || 'unknown',
          dmarc_status: email.dmarc_status || 'unknown'
        }));

        setLoadingProgress(100);
        setEmails(transformedEmails);
        toast({
          title: "Emails chargés",
          description: `${transformedEmails.length} emails trouvés dans ${selectedFolder}`,
        });
      } else {
        throw new Error(data.message);
      }
    } catch (error) {
      console.error('Load emails error:', error);
      toast({
        title: "Erreur",
        description: error.message || "Impossible de charger les emails",
        variant: "destructive",
      });
    } finally {
      clearInterval(progressInterval);
      setLoadingProgress(0);
      setLoading(false);
    }
  };

  const filteredEmails = emails.filter(email => {
    const matchesSearch = email.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      email.from_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      email.from_email.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (authFilter === "all") return matchesSearch;
    if (authFilter === "spf_pass") return matchesSearch && email.spf_status === "pass";
    if (authFilter === "dkim_pass") return matchesSearch && email.dkim_status === "pass";
    if (authFilter === "dmarc_pass") return matchesSearch && email.dmarc_status === "pass";
    if (authFilter === "auth_failed") return matchesSearch && 
      (email.spf_status === "fail" || email.dkim_status === "fail" || email.dmarc_status === "fail");
    
    return matchesSearch;
  });

  const loadEmailContent = async (email: Email) => {
    if (!selectedFolder) return;

    setLoadingContent(true);
    try {
      const { data, error } = await supabase.functions.invoke('imap-connection', {
        body: { 
          action: 'get_email_content',
          email: credentials.email,
          password: credentials.password,
          server: credentials.server,
          folder: selectedFolder,
          emailId: email.id
        }
      });

      if (error) throw error;

      if (data.status === 'success') {
        setEmailContent(data.content.textBody || data.content.body || 'Contenu non disponible');
      } else {
        throw new Error(data.message);
      }
    } catch (error) {
      console.error('Load email content error:', error);
      toast({
        title: "Erreur",
        description: error.message || "Impossible de charger le contenu de l'email",
        variant: "destructive",
      });
      setEmailContent("Erreur lors du chargement du contenu");
    } finally {
      setLoadingContent(false);
    }
  };

  const handleEmailSelect = async (email: Email) => {
    setSelectedEmail(email);
    setEmailContent("");
    await loadEmailContent(email);
  };

  const downloadEmail = async (email: Email) => {
    if (!selectedFolder) return;

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('imap-connection', {
        body: { 
          action: 'get_raw_email',
          email: credentials.email,
          password: credentials.password,
          server: credentials.server,
          folder: selectedFolder,
          emailId: email.id
        }
      });

      if (error) throw error;

      if (data.status === 'success') {
        const rawContent = data.rawContent;
        
        const blob = new Blob([rawContent], { type: 'message/rfc822' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${email.subject.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.eml`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);

        toast({
          title: "Téléchargement réussi",
          description: `Email "${email.subject}" téléchargé au format .eml`,
        });
      } else {
        throw new Error(data.message);
      }
    } catch (error) {
      console.error('Download email error:', error);
      toast({
        title: "Erreur",
        description: error.message || "Impossible de télécharger l'email",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <div className="container mx-auto p-6 space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-primary rounded-2xl shadow-glow">
            <Mail className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-4xl font-bold bg-gradient-primary bg-clip-text text-transparent">
              Outils Email
            </h1>
            <p className="text-lg text-muted-foreground">
              Client IMAP et sanitiseur d'en-têtes email
            </p>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex items-center justify-center rounded-lg bg-muted p-1">
            <button
              onClick={() => setActiveTab("client")}
              className={`inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 ${
                activeTab === "client"
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground"
              }`}
            >
              <Mail className="w-4 h-4 mr-2" />
              Client IMAP
            </button>
            <button
              onClick={() => setActiveTab("sanitizer")}
              className={`inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 ${
                activeTab === "sanitizer"
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground"
              }`}
            >
              <FileText className="w-4 h-4 mr-2" />
              Sanitiseur EML
            </button>
          </div>
        </div>

        {activeTab === "sanitizer" ? (
          <EmailHeaderSanitizer />
        ) : (
          <>
        {/* Connection Form */}
        <Card className="max-w-2xl mx-auto shadow-elegant border-0 bg-card/50 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2">
              <Server className="w-5 h-5" />
              Connexion à votre boîte mail
            </CardTitle>
            <CardDescription>
              Saisissez vos identifiants pour accéder à vos emails
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Adresse email
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="votre@email.com"
                  value={credentials.email}
                  onChange={(e) => setCredentials({...credentials, email: e.target.value})}
                  className="transition-all duration-300 focus:shadow-glow"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="password" className="flex items-center gap-2">
                  <Shield className="w-4 h-4" />
                  Mot de passe
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={credentials.password}
                  onChange={(e) => setCredentials({...credentials, password: e.target.value})}
                  className="transition-all duration-300 focus:shadow-glow"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="server">Serveur IMAP</Label>
              <Input
                id="server"
                placeholder="imap.gmail.com"
                value={credentials.server}
                onChange={(e) => setCredentials({...credentials, server: e.target.value})}
                className="transition-all duration-300 focus:shadow-glow"
              />
            </div>

            <Button 
              onClick={testConnection}
              disabled={loading || !credentials.email || !credentials.password}
              className="w-full bg-gradient-primary hover:opacity-90 transition-all duration-300 hover:shadow-glow"
            >
              {loading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Connexion en cours...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  Tester la connexion
                </div>
              )}
            </Button>

            {connectionStatus.message && (
              <div className={`flex items-center gap-2 p-3 rounded-lg ${
                connectionStatus.connected 
                  ? 'bg-green-50 text-green-800 border border-green-200' 
                  : 'bg-red-50 text-red-800 border border-red-200'
              }`}>
                {connectionStatus.connected ? (
                  <CheckCircle2 className="w-4 h-4" />
                ) : (
                  <AlertCircle className="w-4 h-4" />
                )}
                {connectionStatus.message}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Folder Selection */}
        {connectionStatus.connected && (
          <Card className="max-w-2xl mx-auto shadow-elegant border-0 bg-card/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Sélectionner un dossier</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select value={selectedFolder} onValueChange={setSelectedFolder}>
                <SelectTrigger className="transition-all duration-300 focus:shadow-glow">
                  <SelectValue placeholder="Choisir un dossier" />
                </SelectTrigger>
                <SelectContent>
                  {connectionStatus.folders.map((folder) => (
                    <SelectItem key={folder} value={folder}>
                      {folder}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Button 
                onClick={loadEmails}
                disabled={!selectedFolder || loading}
                className="w-full bg-gradient-accent hover:opacity-90 transition-all duration-300"
              >
                {loading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Chargement...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <ArrowRight className="w-4 h-4" />
                    Charger les emails
                  </div>
                )}
              </Button>

              {loading && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>Chargement des emails...</span>
                    <span>{Math.round(loadingProgress)}%</span>
                  </div>
                  <Progress value={loadingProgress} className="w-full" />
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Email List */}
        {emails.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Email List Panel */}
            <Card className="shadow-elegant border-0 bg-card/50 backdrop-blur-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Mail className="w-5 h-5" />
                    Emails ({filteredEmails.length})
                  </CardTitle>
                  <Badge variant="secondary">{selectedFolder}</Badge>
                </div>
                <div className="space-y-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      placeholder="Rechercher dans les emails..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 transition-all duration-300 focus:shadow-glow"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Label className="text-sm font-medium">Filtrer par authentification:</Label>
                    <Select value={authFilter} onValueChange={setAuthFilter}>
                      <SelectTrigger className="w-48">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Tous les emails</SelectItem>
                        <SelectItem value="spf_pass">SPF valide</SelectItem>
                        <SelectItem value="dkim_pass">DKIM valide</SelectItem>
                        <SelectItem value="dmarc_pass">DMARC valide</SelectItem>
                        <SelectItem value="auth_failed">Échecs d'authentification</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-96">
                  <div className="space-y-1 p-4">
                    {filteredEmails.map((email) => (
                      <div
                        key={email.id}
                        onClick={() => handleEmailSelect(email)}
                        className={`p-4 rounded-lg cursor-pointer transition-all duration-200 hover:bg-accent/50 ${
                          selectedEmail?.id === email.id ? 'bg-accent/70 shadow-md' : 'hover:shadow-sm'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <User className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                              <span className="font-medium text-sm truncate">
                                {email.from_name}
                              </span>
                              {email.hasAttachments && (
                                <Badge variant="outline" className="text-xs">
                                  📎
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground truncate mb-1">
                              {email.from_email}
                            </p>
                            <p className="text-sm font-medium truncate">
                              {email.subject}
                            </p>
                            <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                              <Calendar className="w-3 h-3" />
                              {email.date}
                              <span>•</span>
                              {email.size}
                            </div>
                            <div className="flex items-center gap-1 mt-2">
                              <Badge 
                                variant={email.spf_status === 'pass' ? 'default' : email.spf_status === 'fail' ? 'destructive' : 'secondary'} 
                                className="text-xs"
                              >
                                SPF: {email.spf_status}
                              </Badge>
                              <Badge 
                                variant={email.dkim_status === 'pass' ? 'default' : email.dkim_status === 'fail' ? 'destructive' : 'secondary'} 
                                className="text-xs"
                              >
                                DKIM: {email.dkim_status}
                              </Badge>
                              <Badge 
                                variant={email.dmarc_status === 'pass' ? 'default' : email.dmarc_status === 'fail' ? 'destructive' : 'secondary'} 
                                className="text-xs"
                              >
                                DMARC: {email.dmarc_status}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Email Preview Panel */}
            <Card className="shadow-elegant border-0 bg-card/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Aperçu de l'email</CardTitle>
              </CardHeader>
              <CardContent>
                {selectedEmail ? (
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-semibold text-lg mb-2">{selectedEmail.subject}</h3>
                      <div className="space-y-2 text-sm text-muted-foreground">
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4" />
                          <span className="font-medium">{selectedEmail.from_name}</span>
                          <span>&lt;{selectedEmail.from_email}&gt;</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          {selectedEmail.date}
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="bg-muted/50 p-4 rounded-lg max-h-64 overflow-y-auto">
                      {loadingContent ? (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <div className="w-4 h-4 border-2 border-muted-foreground/30 border-t-muted-foreground rounded-full animate-spin" />
                          Chargement du contenu...
                        </div>
                      ) : (
                        <pre className="text-sm text-muted-foreground whitespace-pre-wrap font-sans">
                          {emailContent || 'Sélectionnez un email pour voir son contenu'}
                        </pre>
                      )}
                    </div>
                    
                    <Button 
                      onClick={() => downloadEmail(selectedEmail)}
                      className="w-full bg-gradient-primary hover:opacity-90 transition-all duration-300"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Télécharger l'email
                    </Button>
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <Mail className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Sélectionnez un email pour voir l'aperçu</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
          </>
        )}
      </div>
    </div>
  );
}
