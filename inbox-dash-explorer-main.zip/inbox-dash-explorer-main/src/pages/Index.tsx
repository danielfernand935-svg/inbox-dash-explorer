import EmailClient from "@/components/EmailClient";

const Index = () => {
  return <EmailClient />;
};

export default Index;
